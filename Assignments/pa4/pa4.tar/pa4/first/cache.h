typedef struct cache{
    int setSize;
    int sets;
    int blockSize;
    int cacheSize;
} Cache;
