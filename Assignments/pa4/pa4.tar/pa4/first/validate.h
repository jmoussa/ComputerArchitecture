int validate(char* , char* , char* , Cache* );
