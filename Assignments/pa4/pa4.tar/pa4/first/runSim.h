int simulate(Cache *, char *);
